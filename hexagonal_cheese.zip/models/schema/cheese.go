package schema

type Cheese struct {
    ID               int
    Name             string
    OriginCountryID  int
    CheeseType       string
    Description      string
}